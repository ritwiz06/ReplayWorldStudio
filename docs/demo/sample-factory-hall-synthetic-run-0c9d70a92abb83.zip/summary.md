# Sample factory hall (synthetic): the same shift before and after a layout change

**Synthetic example.** The hall, its drawing and its shift are made up for this repository; nothing describes a real factory.

**Results under stated assumptions.** Predicts what happens under the assumptions listed here, on this layout. It does not verify real productivity, worker safety, forces, structural strength or chemistry, and the equipment models are illustrations: their insides are not simulated.

## What changed and what happened

- Rack A (material) ↔ Mixer is blocked in the edited layout (Blocked: the best way through narrows to 0.50 m between Rack A and Machine B, and the item needs 0.80 m). It is needed for carrying from Rack A (material) to Mixer and Worker 1 (mixing) walking, so that cannot happen; nothing is moved through equipment.
- Mixer ↔ Machine B is blocked in the edited layout (Blocked at the destination: the destination point is inside Rack B, and the item needs 0.40 m on each side). It is needed for carrying from Mixer to Machine B and Worker 1 (mixing) walking, so that cannot happen; nothing is moved through equipment.
- Machine B ↔ Packing table is blocked in the edited layout (Blocked at the start: the start point is inside Rack B, and the item needs 0.40 m on each side). It is needed for carrying from Machine B to Packing table and Worker 2 (forming) walking, so that cannot happen; nothing is moved through equipment.
- Rack A (material) ↔ Machine B is blocked in the edited layout (Blocked at the destination: the destination point is inside Rack B, and the item needs 0.40 m on each side). It is needed for Worker 1 (mixing) walking, so that cannot happen; nothing is moved through equipment.
- Output goes from 102 to 0 completed batches (−102).

| | Original layout | Edited layout | Change |
| --- | --- | --- | --- |
| Completed batches | 102 | 0 | −102 |
| Unfinished at the shift end | 8 | 0 | −8 |
| Mixer: busy | 79 % | 0 % | −79 pts |
| Mixer: longest queue | 1 | 0 | −1 |
| Mixer: blocked | 1 % | 0 % | −1 pts |
| Machine B: busy | 52 % | 0 % | −52 pts |
| Machine B: longest queue | 2 | 0 | −2 |
| Packing table: busy | 86 % | 0 % | −86 pts |
| Packing table: longest queue | 4 | 0 | −4 |
| Worker 1 (mixing): working, carrying or walking | 54 % | 0 % | −54 pts |
| Worker 2 (forming): working, carrying or walking | 27 % | 0 % | −27 pts |
| Worker 3 (packing): working, carrying or walking | 86 % | 0 % | −86 pts |

Both runs use the same process, seed and engine; only the layout differs.

## Runs

| Layout | Outcome | Completed batches | Unfinished | Events | Event fingerprint | Layout fingerprint |
| --- | --- | --- | --- | --- | --- | --- |
| original | ready | 102 | 8 | 2160 | 0e2f103ae1a2eb | 0b86c1f5eef036 |
| edited | blocked | 0 | 0 | 9 | 0c9d70a92abb83 | 1ba0b1d92851c8 |

Engine rws-run/1, seed 1, process fingerprint 1925980832dc4a, contract 0.14.0.

**Edited layout:**

- Rack A (material) ↔ Mixer is blocked for carrying from Rack A (material) to Mixer, Worker 1 (mixing) walking: Blocked: the best way through narrows to 0.50 m between Rack A and Machine B, and the item needs 0.80 m.
- Mixer ↔ Machine B is blocked for carrying from Mixer to Machine B, Worker 1 (mixing) walking: Blocked at the destination: the destination point is inside Rack B, and the item needs 0.40 m on each side.
- Machine B ↔ Packing table is blocked for carrying from Machine B to Packing table, Worker 2 (forming) walking: Blocked at the start: the start point is inside Rack B, and the item needs 0.40 m on each side.
- Rack A (material) ↔ Machine B is blocked for Worker 1 (mixing) walking: Blocked at the destination: the destination point is inside Rack B, and the item needs 0.40 m on each side.

## Layout evidence (the drawing and its review)

- The layout was read from layout-checks-mm.dxf (DXF, sha256 5937cfd896ae…) and reviewed in the app: floor outline (accepted), scale confirmed, 12 drawn outlines reviewed.
- A drawing shows a design: the intended arrangement and sizes, as reviewed. It is not a survey of a built site, and nothing here was measured on one.
- The drawing is a synthetic example made for this repository (fixtures/drawings/layout-checks-mm.dxf); it describes no real hall.
- The edited layout differs from the drawing: Machine B moved 7.09 m.

## Operating inputs and their basis

An example to show how Run a day works. Every time, capacity, speed, break and worker assignment here is an assumption made up for this synthetic hall: not data from a real factory, and nothing is read from the drawing.

| Input | Value | Basis |
| --- | --- | --- |
| Shift start (seconds after midnight) | 21600 s | example assumption |
| Shift length | 28800 s | example assumption |
| Morning break: starts after the shift start | 10800 s | example assumption |
| Morning break: length | 900 s | example assumption |
| Lunch: starts after the shift start | 19800 s | example assumption |
| Lunch: length | 1800 s | example assumption |
| Rack A (material): where a worker stands | x -3.50 m, z 1.50 m from the object's centre; material is always available here | example assumption |
| Mixer: where a worker stands | x 1.59 m, z 1.59 m from the object's centre | example assumption |
| Mixer: time with a worker | 60 s | example assumption |
| Mixer: time on its own | 150 s | example assumption |
| Mixer: queue (input) places | 1 items | example assumption |
| Mixer: output places | 1 items | example assumption |
| Machine B: where a worker stands | x 0.00 m, z 1.10 m from the object's centre | example assumption |
| Machine B: time with a worker | 20 s | example assumption |
| Machine B: time on its own | 120 s | example assumption |
| Machine B: queue (input) places | 2 items | example assumption |
| Machine B: output places | 2 items | example assumption |
| Machine B: Changeover (example) starts after the shift start | 14400 s | example assumption |
| Machine B: Changeover (example) length | 1200 s | example assumption |
| Packing table: where a worker stands | x 0.00 m, z -0.90 m from the object's centre | example assumption |
| Packing table: time with a worker | 240 s | example assumption |
| Packing table: time on its own | 0 s | example assumption |
| Packing table: queue (input) places | 4 items | example assumption |
| Packing table: output places | 1 items | example assumption |
| Carry Rack A (material) → Mixer: item width | 0.6 m | example assumption |
| Carry Rack A (material) → Mixer: clearance each side | 0.1 m | example assumption |
| Carry Rack A (material) → Mixer: speed | 1 m/s | example assumption |
| Carry Rack A (material) → Mixer: pick up, and again set down | 10 s | example assumption |
| Carry Mixer → Machine B: item width | 0.6 m | example assumption |
| Carry Mixer → Machine B: clearance each side | 0.1 m | example assumption |
| Carry Mixer → Machine B: speed | 1 m/s | example assumption |
| Carry Mixer → Machine B: pick up, and again set down | 10 s | example assumption |
| Carry Machine B → Packing table: item width | 0.6 m | example assumption |
| Carry Machine B → Packing table: clearance each side | 0.1 m | example assumption |
| Carry Machine B → Packing table: speed | 1 m/s | example assumption |
| Carry Machine B → Packing table: pick up, and again set down | 10 s | example assumption |
| Worker 1 (mixing): walking speed | 1.2 m/s | example assumption |
| Worker 1 (mixing): walking width | 0.8 m | example assumption |
| Worker 2 (forming): walking speed | 1.2 m/s | example assumption |
| Worker 2 (forming): walking width | 0.8 m | example assumption |
| Worker 3 (packing): walking speed | 1.2 m/s | example assumption |
| Worker 3 (packing): walking width | 0.8 m | example assumption |

0 entered, 42 example assumptions. Seed 1: used only for unplanned stops, if any are entered.

## What this shows and does not show

- These are the results of a deterministic event model under the operating inputs listed; they are not measurements and do not predict real output.
- Inputs marked as example or illustrative assumptions were not measured or entered by anyone for a real site.
- Routes are width-only checks on the reviewed plan (no turning and no congestion between workers).
- It does not verify real productivity, worker safety, forces, structural strength, clearances or chemistry; equipment models are illustrations and their insides are not simulated.

