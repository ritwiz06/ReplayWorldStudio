# Evidence bundle: Sample factory hall (synthetic)

Made with Replay World Studio on 2026-10-19T22:18:29Z (UTC): contract 0.14.0, engine rws-run/1, seed 1.

**Synthetic example. Results under stated assumptions.** Predicts what happens under the assumptions listed here, on this layout. It does not verify real productivity, worker safety, forces, structural strength or chemistry, and the equipment models are illustrations: their insides are not simulated.

## What is in it

| File | What it is |
| --- | --- |
| README.md | This file. |
| summary.md | The before/after summary in words: what changed, what happened and why, and what every number rests on. |
| manifest.json | Every file with its sha256; contract and engine versions, seed, fingerprints of each layout, process and event log; the basis of every operating input. |
| project.json | The project: the reviewed layout (as edited), the drawing reading, the process and the edit record. |
| runs/original/events.json | The original layout's event log, as the engine produced it. |
| runs/original/metrics.json | The original layout's routes and whole-shift results. |
| runs/edited/events.json | The edited layout's event log, as the engine produced it. |
| runs/edited/metrics.json | The edited layout's routes and whole-shift results. |
| files/drawings/5937cfd896aea81b21bf50425a7f3cffe8b1452183bd87f2c5b062b3c367aa26.dxf | A source file the project names (drawings/5937cfd896aea81b21bf50425a7f3cffe8b1452183bd87f2c5b062b3c367aa26.dxf). |

## Open it and run it again

You need a checkout of the Replay World Studio repository (git), Node.js 22.12 or newer with pnpm, and uv (it installs the Python version the repository names). No API key, account or network service is needed to open or rerun a bundle; installing needs the internet once.

1. In the repository: `uv sync --locked`, `pnpm install --frozen-lockfile`, then `pnpm start`, and open the address it prints (http://127.0.0.1:8000 by default).
2. **Open** (top bar), and choose this ZIP. The app checks every file against manifest.json and refuses a changed or damaged bundle.
3. In the **Run** tab, press **Run both layouts again**. The app reruns each layout with the same process and seed, and compares the event logs, fingerprints, counts and explanation with the recorded ones.

Everything the project names is in the bundle or part of the repository, so the runs and the plan drawing open as recorded.

## Conventions

- Event times (t) and durations (ms) are whole milliseconds from the shift start; a clock time is the shift start plus t. Operating inputs are in the units listed with them (seconds, metres, metres per second, items).
- Each events.json lists the events exactly as the engine produced them, in the order it processed them: by time, then in the order they were scheduled. Ties at the same millisecond keep that order.
- Numbers in an event (worker, station, transfer, from, to) are positions in the tables of the same events.json (workers, stations, transfers, locations). Item numbers count from 0 in the order items were created at the supply.
- Anything at or after the shift end does not happen. An item counts as completed if its last step ends before the shift ends.
- Shares in metrics.json are fractions (0 to 1) of the shift. Route lengths are metres along the route the route check found.
- event_fingerprint: cyrb53 (53-bit) of the events array as compact JSON (JSON.stringify), 14 hex digits. process_fingerprint and layout_fingerprint: the same hash of the process, and of the layout's scene objects. Files are identified by sha256 in this manifest.

## What this shows and does not show

- These are the results of a deterministic event model under the operating inputs listed; they are not measurements and do not predict real output.
- Inputs marked as example or illustrative assumptions were not measured or entered by anyone for a real site.
- Routes are width-only checks on the reviewed plan (no turning and no congestion between workers).
- It does not verify real productivity, worker safety, forces, structural strength, clearances or chemistry; equipment models are illustrations and their insides are not simulated.

